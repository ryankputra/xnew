from kyt import *
import asyncio

@bot.on(events.CallbackQuery(data=b'create-vless'))
async def create_vless(event):
    async def create_vless_(event):
        chat = event.chat_id
        sender = await event.get_sender()
        
        async with bot.conversation(chat) as conv:
            await event.respond('**Username:**')
            user = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = (await user).raw_text

            await event.respond("**Quota:**")
            pw = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            pw = (await pw).raw_text

            await event.respond("**Limit-ip:**")
            pw1 = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            pw1 = (await pw1).raw_text

            await event.respond("**Expired:**")
            exp = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            exp = (await exp).raw_text

        await event.edit("Processing...")
        await asyncio.sleep(1)  # Use asyncio.sleep instead of time.sleep

        for i in [0, 4, 8, 20, 36, 52, 84, 100]:
            await event.edit(f"`Processing... {i}%\n" + "█" * (i // 2) + "▒" * (50 - i // 2))
            await asyncio.sleep(1 if i % 20 == 0 else 0.5)

        await event.edit("`Wait.. Setting up an Account`")
        cmd = f'printf "%s\n" "{user}" "{pw}" "{pw1}" "{exp}" | add-vle'
        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
            x = [x.group() for x in re.finditer("vless://(.*)", a)]
            uuid = re.search("vless://(.*?)@", x[0]).group(1)

            today = DT.date.today()
            later = today + DT.timedelta(days=int(exp))
            msg = f"""
**━━━━━━━━━━━━━━━━━**
**🐾🕊️ Xray/Vless Account 🕊️🐾**
**━━━━━━━━━━━━━━━━━**
**» Remarks     :** `{user}`
**» Host Server :** `{DOMAIN}`
**» Host XrayDNS:** `{HOST}`
**» User Quota  :** `{pw} GB`
**» Port DNS    :** `443, 53`
**» Port TLS    :** `222-1000`
**» Port NTLS   :** `80, 8080, 8081-9999`
**» NetWork     :** `(WS) or (gRPC)`
**» User ID     :** `{uuid}`
**» Path Vless  :** `(/multi path)/vless `
**» Path Dynamic:** `http://BUG.COM/vless `
**» Pub Key     :** `{PUB}`
**━━━━━━━━━━━━━━━━━**
**» Link TLS   : **
`{x[0]}`
**━━━━━━━━━━━━━━━━━**
**» Link NTLS  :**
`{x[1].replace(" ","")}`
**━━━━━━━━━━━━━━━━━**
**» Link GRPC  :**
`{x[2].replace(" ","")}`
**━━━━━━━━━━━━━━━━━**
**» Format OpenClash :** https://{DOMAIN}:81/vless-{user}.txt
**━━━━━━━━━━━━━━━━━**
**» Expired Until:** `{later}`
**» 🤖@RyyVpn26**
"""
            await event.respond(msg)

        except subprocess.CalledProcessError:
            await event.respond(f"**Klik Link di atas untuk membuka Detail Account** `{user}` **Successfully Created**")

    a = valid(str(sender.id))
    if a == "true":
        await create_vless_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)

@bot.on(events.CallbackQuery(data=b'cek-vless'))
async def cek_vless(event):
    async def cek_vless_(event):
        cmd = 'bot-cek-vless'.strip()
        try:
            z = subprocess.check_output(cmd, shell=True).decode("utf-8")
            await event.respond(f"{z}\n**Shows Logged In Users Vless**\n**» 🤖@RyyVpn26**", buttons=[[Button.inline("‹ Main Menu ›", "menu")]])
        except subprocess.CalledProcessError as e:
            await event.respond(f"Error: {e.output}")

    a = valid(str(sender.id))
    if a == "true":
        await cek_vless_(event)
    else:
        await event.answer("Access Denied", alert=True)

@bot.on(events.CallbackQuery(data=b'lock-vless'))
async def lock_vless(event):
    async def lock_vless_(event):
        chat = event.chat_id
        sender = await event.get_sender()
        
        async with bot.conversation(chat) as conv:
            await event.respond("**Username:**")
            exp = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            exp = (await exp).raw_text

        await event.edit("Processing...")
        await asyncio.sleep(1)
        
        cmd = f'printf "%s\n" "{exp}" | lock-vl'
        try:
            subprocess.check_output(cmd, shell=True)
            await event.respond(f"**User** `{exp}` **Successfully Locked**")
        except subprocess.CalledProcessError:
            await event.respond(f"**Failed to lock user** `{exp}`")

    a = valid(str(sender.id))
    if a == "true":
        await lock_vless_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)

@bot.on(events.CallbackQuery(data=b'unlock-vless'))
async def unlock_vless(event):
    async def unlock_vless_(event):
        chat = event.chat_id
        sender = await event.get_sender()
        
        async with bot.conversation(chat) as conv:
            await event.respond("**Username:**")
            exp = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            exp = (await exp).raw_text

        await event.edit("Processing...")
        await asyncio.sleep(1)

        cmd = f'printf "%s\n" "{exp}" | unlock-vl'
        try:
            subprocess.check_output(cmd, shell=True)
            await event.respond(f"**User** `{exp}` **Successfully Unlocked**")
        except subprocess.CalledProcessError:
            await event.respond(f"**Failed to unlock user** `{exp}`")

    a = valid(str(sender.id))
    if a == "true":
        await unlock_vless_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)

@bot.on(events.CallbackQuery(data=b'delete-vless'))
async def delete_vless(event):
    async def delete_vless_(event):
        chat = event.chat_id
        sender = await event.get_sender()

        async with bot.conversation(chat) as conv:
            await event.respond('**Username:**')
            user = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = (await user).raw_text

        cmd = f'printf "%s\n" "{user}" | del-vle'
        try:
            subprocess.check_output(cmd, shell=True)
            await event.respond(f"**User** `{user}` **Successfully Deleted**")
        except subprocess.CalledProcessError:
            await event.respond(f"**Failed to delete user** `{user}`")

    a = valid(str(sender.id))
    if a == "true":
        await delete_vless_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)

@bot.on(events.CallbackQuery(data=b'trial-vless'))
async def trial_vless(event):
    async def trial_vless_(event):
        chat = event.chat_id
        sender = await event.get_sender()

        async with bot.conversation(chat) as conv:
            await event.respond("**Minutes:**")
            exp = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            exp = (await exp).raw_text

        await event.edit("Processing...")
        await asyncio.sleep(1)

        cmd = f'printf "%s\n" "{exp}" | trial-vle'
        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
            x = [x.group() for x in re.finditer("vless://(.*)", a)]
            remarks = re.search("#(.*)", x[0]).group(1)
            uuid = re.search("vless://(.*?)@", x[0]).group(1)

            msg = f"""
**━━━━━━━━━━━━━━━━━**
**🐾🕊️ Xray/Vless Account 🕊️🐾**
**━━━━━━━━━━━━━━━━━**
**» Remarks     :** `{remarks}`
**» Host Server :** `{DOMAIN}`
**» Host XrayDNS:** `{HOST}`
**» User Quota  :** `Unlimited`
**» Port DNS    :** `443, 53`
**» Port TLS    :** `222-1000`
**» Port NTLS   :** `80, 8080, 8081-9999`
**» NetWork     :** `(WS) or (gRPC)`
**» User ID     :** `{uuid}`
**» Path Vless  :** `(/multi path)/vless `
**» Path Dynamic:** `http://BUG.COM/vless `
**» Pub Key     :** `{PUB}`
**━━━━━━━━━━━━━━━━━**
**» Link TLS   : **
`{x[0]}`
**━━━━━━━━━━━━━━━━━**
**» Link NTLS  :**
`{x[1].replace(" ","")}`
**━━━━━━━━━━━━━━━━━**
**» Link GRPC  :**
`{x[2].replace(" ","")}`
**━━━━━━━━━━━━━━━━━**
**» Format OpenClash :** https://{DOMAIN}:81/vless-{remarks}.txt
**━━━━━━━━━━━━━━━━━**
**» Expired Until:** `{exp} Minutes`
**» 🤖@RyyVpn26**
"""
            await event.respond(msg)

        except subprocess.CalledProcessError:
            await event.respond(f"**Failed to create trial account**")

    a = valid(str(sender.id))
    if a == "true":
        await trial_vless_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)
