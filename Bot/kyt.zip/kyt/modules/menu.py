from kyt import *

admin_username = "@RyyVpn26"  # Username admin untuk proses topup
admin_id = 6583386476  # ID admin terbaru

def check_balance(user_id, required_balance):
    balance = get_user_balance(user_id)
    return balance >= required_balance

def is_reseller(user_id):
    return get_user_role(user_id) == "reseller"

def is_member(user_id):
    return get_user_status(user_id) == "member"

@bot.on(events.NewMessage(pattern=r"(?:.menu|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def check_before_menu(event):
    sender = await event.get_sender()
    val = valid(str(sender.id))
    
    # Pastikan pengguna adalah member
    if val == "false" or not is_member(sender.id):
        try:
            await event.answer("Akses Ditolak. Anda harus menjadi member untuk mengakses bot ini.", alert=True)
        except:
            await event.reply("Akses Ditolak. Anda harus menjadi member untuk mengakses bot ini.")
        return

    # Cek apakah saldo mencukupi untuk mengakses layanan
    if is_reseller(sender.id):
        required_balance = 6000
    else:
        required_balance = 10000
    
    # Jika saldo kurang dari minimal (untuk member regular maupun reseller)
    if not check_balance(sender.id, required_balance):
        inline_topup_reseller = [
            [Button.inline("💳 TOPUP SALDO", "topup")],
            [Button.inline("💼 RESELLER MENU", "reseller")],
            [Button.inline("‹ Back", "start")]
        ]
        await event.reply(f"Saldo Anda tidak mencukupi untuk mengakses menu utama. Silakan lakukan topup minimal 20.000 rupiah dengan menghubungi admin {admin_username} atau gunakan menu reseller.", buttons=inline_topup_reseller)
        return

    # Jika pengguna valid dan saldo mencukupi, tampilkan menu utama
    await show_main_menu(event)

async def show_main_menu(event):
    inline = [
        [Button.inline(" SSH OVPN MANAGER ","ssh")],
        [Button.inline(" VMESS MANAGER ","vmess"),
         Button.inline(" VLESS MANAGER ","vless")],
        [Button.inline(" TROJAN MANAGER ","trojan"),
         Button.inline(" SHDWSK MANAGER ","shadowsocks")],
        [Button.inline(" CHECK VPS INFO ","info"),
         Button.inline(" OTHER SETTING ","setting")],
        [Button.inline(" ‹ Back Menu › ","start")]
    ]

    sh = f' cat /etc/passwd | grep "home" | grep "false" | wc -l'
    ssh = subprocess.check_output(sh, shell=True).decode("ascii")
    vm = f' cat /etc/vmess/.vmess.db | grep "###" | wc -l'
    vms = subprocess.check_output(vm, shell=True).decode("ascii")
    vl = f' cat /etc/vless/.vless.db | grep "###" | wc -l'
    vls = subprocess.check_output(vl, shell=True).decode("ascii")
    tr = f' cat /etc/trojan/.trojan.db | grep "###" | wc -l'
    trj = subprocess.check_output(tr, shell=True).decode("ascii")
    sdss = f" cat /etc/os-release | grep -w PRETTY_NAME | head -n1 | sed 's/=//g' | sed 's/PRETTY_NAME//g'"
    namaos = subprocess.check_output(sdss, shell=True).decode("ascii")
    ipvps = f" curl -s ipv4.icanhazip.com"
    ipsaya = subprocess.check_output(ipvps, shell=True).decode("ascii")
    citsy = f" cat /etc/xray/city"
    city = subprocess.check_output(citsy, shell=True).decode("ascii")

    msg = f"""
━━━━━━━━━━━━━━━━━
**🇮🇩 ADMIN PANEL MENU 🇮🇩**
━━━━━━━━━━━━━━━━━
**» OS     :** `{namaos.strip().replace('"','')}`
**» CITY :** `{city.strip()}`
**» DOMAIN :** `{DOMAIN}`
**» IP VPS :** `{ipsaya.strip()}`
**» Total Account Created:** 

**» 🚀SSH OVPN    :** `{ssh.strip()}` __account__
**» 🎭XRAY VMESS  :** `{vms.strip()}` __account__
**» 🗼XRAY VLESS  :** `{vls.strip()}` __account__
**» 🎯XRAY TROJAN :** `{trj.strip()}` __account__
━━━━━━━━━━━━━━━━━━━━━━━ 
"""
    x = await event.edit(msg,buttons=inline)
    if not x:
        await event.reply(msg,buttons=inline)

# Tambahkan fungsi cek saldo pengguna (contoh saja)
def get_user_balance(user_id):
    # Mengambil saldo dari database atau sistem lainnya
    return 30000  # Contoh saldo sementara

# Periksa role pengguna, misalnya apakah reseller atau bukan
def get_user_role(user_id):
    # Mengambil role dari database
    return "regular"  # Contoh: regular atau reseller

# Periksa status keanggotaan (contoh untuk member)
def get_user_status(user_id):
    # Mengambil status dari database
    return "member"

