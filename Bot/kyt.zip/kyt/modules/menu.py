from kyt import *

admin_username = "@RyyVpn26"  # Username admin untuk proses topup
admin_id = 6583386476  # ID admin terbaru

# Simpan status pengguna dan saldo dalam dictionary untuk simulasi (gantikan dengan database sesuai kebutuhan)
user_data = {}

def check_balance(user_id, required_balance):
    balance = get_user_balance(user_id)
    return balance >= required_balance

def is_reseller(user_id):
    return get_user_role(user_id) == "reseller"

def is_member(user_id):
    # Periksa apakah pengguna sudah terdaftar sebagai member
    return user_data.get(user_id, {}).get("status") == "member"

async def deduct_balance(user_id, amount):
    if user_id in user_data:
        user_data[user_id]["balance"] -= amount

@bot.on(events.NewMessage(pattern=r"/start"))
async def start(event):
    sender = await event.get_sender()
    inline_start = [
        [Button.inline("💳 TOPUP SALDO", "topup")],
        [Button.inline("💼 DAFTAR MEMBER", "join_member")],
        [Button.inline("📦 MENU RESELLER", "reseller")],
        [Button.inline("📋 MENU UTAMA", "menu")]
    ]
    
    msg = f"""
Selamat datang di Bot Layanan SSH, VMess, VLess, Trojan, dan Shadowsocks!

Anda dapat melakukan hal berikut:
- **Topup Saldo:** Lakukan topup saldo untuk membeli akun layanan.
- **Daftar Member:** Menjadi member agar bisa mengakses menu bot.
- **Menu Reseller:** Informasi cara menjadi reseller dengan keuntungan harga lebih murah.
- **Menu Utama:** Akses panel utama setelah Anda terdaftar dan memiliki saldo yang cukup.

Silakan pilih salah satu opsi di bawah ini atau gunakan perintah:
- `/menu` untuk mengakses menu utama.
- `/join` untuk mendaftar sebagai member.
    """
    await event.reply(msg, buttons=inline_start)

@bot.on(events.NewMessage(pattern=r"(?:.menu|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def check_before_menu(event):
    sender = await event.get_sender()
    
    if not is_member(sender.id):
        try:
            await event.answer("Akses Ditolak. Anda harus menjadi member untuk mengakses bot ini.", alert=True)
        except:
            await event.reply("Akses Ditolak. Anda harus menjadi member untuk mengakses bot ini.")
        return

    # Cek apakah saldo mencukupi
    required_balance = 6000 if is_reseller(sender.id) else 10000
    if not check_balance(sender.id, required_balance):
        inline_topup_reseller = [
            [Button.inline("💳 TOPUP SALDO", "topup")],
            [Button.inline("💼 RESELLER MENU", "reseller")],
            [Button.inline("‹ Back", "start")]
        ]
        await event.reply(f"Saldo Anda tidak mencukupi untuk mengakses menu utama. Silakan lakukan topup minimal 20.000 rupiah dengan menghubungi admin {admin_username} atau gunakan menu reseller.", buttons=inline_topup_reseller)
        return

    await show_main_menu(event)

async def show_main_menu(event):
    inline = [
        [Button.inline(" SSH OVPN MANAGER ","ssh")],
        [Button.inline(" VMESS MANAGER ","vmess"),
         Button.inline(" VLESS MANAGER ","vless")],
        [Button.inline(" TROJAN MANAGER ","trojan"),
         Button.inline(" SHDWSK MANAGER ","shadowsocks")],
        [Button.inline(" CHECK VPS INFO ","info"),
         Button.inline(" OTHER SETTING ","setting")],
        [Button.inline(" ‹ Back Menu › ","start")]
    ]

    await event.reply("Panel Utama", buttons=inline)

@bot.on(events.CallbackQuery(data=b'topup'))
async def topup_request(event):
    await event.reply(f"Silakan hubungi admin {admin_username} untuk melakukan topup saldo. Sertakan username Anda saat menghubungi admin.")

@bot.on(events.CallbackQuery(data=b'reseller'))
async def reseller_request(event):
    await event.reply(f"Untuk menjadi reseller, silakan topup minimal 50.000 rupiah dengan menghubungi admin {admin_username}.")

@bot.on(events.NewMessage(pattern=r"/join"))
async def join_member(event):
    sender = await event.get_sender()
    if is_member(sender.id):
        await event.reply("Anda sudah menjadi member.")
        return
    
    add_member(sender.id)
    await event.reply(f"Selamat {sender.first_name}, Anda sekarang menjadi member! Anda dapat melakukan topup untuk menggunakan layanan bot.")

@bot.on(events.NewMessage(pattern=r"^/addsaldo (\d+) (\d+) (reseller|regular)$"))
async def add_saldo(event):
    if event.sender_id != admin_id:
        await event.reply("Anda tidak memiliki akses untuk menggunakan perintah ini.")
        return
    
    args = event.pattern_match.groups()
    user_id = int(args[0])
    amount = int(args[1])
    role = args[2]
    
    add_balance(user_id, amount, role)
    await event.reply(f"Saldo sebesar {amount} berhasil ditambahkan ke pengguna {user_id} sebagai {role}.")

# Placeholder functions for user data and balance management
def get_user_balance(user_id):
    return user_data.get(user_id, {}).get("balance", 0)

def add_balance(user_id, amount, role):
    if user_id not in user_data:
        user_data[user_id] = {"balance": 0, "status": "non-member"}
    user_data[user_id]["balance"] += amount
    user_data[user_id]["role"] = role

def get_user_role(user_id):
    return user_data.get(user_id, {}).get("role", "regular")

def get_user_status(user_id):
    return user_data.get(user_id, {}).get("status", "non-member")

def add_member(user_id):
    if user_id not in user_data:
        user_data[user_id] = {"balance": 0, "status": "non-member"}
    user_data[user_id]["status"] = "member"

@bot.on(events.CallbackQuery(data=b'create_account'))
async def create_account(event):
    sender = await event.get_sender()
    
    if not is_member(sender.id):
        await event.answer("Akses Ditolak. Anda harus menjadi member untuk membuat akun.", alert=True)
        return
    
    # Tentukan jumlah yang akan dipotong
    amount_to_deduct = 6000 if is_reseller(sender.id) else 10000
    
    # Cek saldo dan kurangi saldo
    if not check_balance(sender.id, amount_to_deduct):
        await event.reply(f"Saldo Anda tidak mencukupi untuk membuat akun. Silakan topup minimal {amount_to_deduct} rupiah.")
        return

    # Kurangi saldo
    await deduct_balance(sender.id, amount_to_deduct)
    
    # Lanjutkan dengan proses pembuatan akun
    await event.reply("Akun Anda berhasil dibuat!")  # Ganti dengan logika pembuatan akun yang sebenarnya.

