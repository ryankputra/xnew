from kyt import *

admin_username = "@RyyVpn26"  # Username admin untuk proses topup
admin_id = 6583386476  # ID admin terbaru

def check_balance(user_id, required_balance):
    balance = get_user_balance(user_id)
    return balance >= required_balance

def is_reseller(user_id):
    return get_user_role(user_id) == "reseller"

def is_member(user_id):
    return get_user_status(user_id) == "member"

@bot.on(events.NewMessage(pattern=r"/start"))
async def start(event):
    sender = await event.get_sender()
    inline_start = [
        [Button.inline("💳 TOPUP SALDO", "topup")],
        [Button.inline("💼 DAFTAR MEMBER", "join_member")],
        [Button.inline("📦 MENU RESELLER", "reseller")],
        [Button.inline("📋 MENU UTAMA", "menu")]
    ]
    
    msg = f"""
Selamat datang di Bot Layanan SSH, VMess, VLess, Trojan, dan Shadowsocks!

Anda dapat melakukan hal berikut:
- **Topup Saldo:** Lakukan topup saldo untuk membeli akun layanan.
- **Daftar Member:** Menjadi member agar bisa mengakses menu bot.
- **Menu Reseller:** Informasi cara menjadi reseller dengan keuntungan harga lebih murah.
- **Menu Utama:** Akses panel utama setelah Anda terdaftar dan memiliki saldo yang cukup.

Silakan pilih salah satu opsi di bawah ini atau gunakan perintah:
- `/menu` untuk mengakses menu utama.
- `/join` untuk mendaftar sebagai member.
    """
    await event.reply(msg, buttons=inline_start)

@bot.on(events.NewMessage(pattern=r"(?:.menu|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def check_before_menu(event):
    sender = await event.get_sender()
    val = valid(str(sender.id))
    
    if val == "false" or not is_member(sender.id):
        try:
            await event.answer("Akses Ditolak. Anda harus menjadi member untuk mengakses bot ini.", alert=True)
        except:
            await event.reply("Akses Ditolak. Anda harus menjadi member untuk mengakses bot ini.")
        return

    # Cek apakah saldo mencukupi
    required_balance = 6000 if is_reseller(sender.id) else 10000
    if not check_balance(sender.id, required_balance):
        inline_topup_reseller = [
            [Button.inline("💳 TOPUP SALDO", "topup")],
            [Button.inline("💼 RESELLER MENU", "reseller")],
            [Button.inline("‹ Back", "start")]
        ]
        await event.reply(f"Saldo Anda tidak mencukupi untuk mengakses menu utama. Silakan lakukan topup minimal 20.000 rupiah dengan menghubungi admin {admin_username} atau gunakan menu reseller.", buttons=inline_topup_reseller)
        return

    await show_main_menu(event)

async def show_main_menu(event):
    inline = [
        [Button.inline(" SSH OVPN MANAGER ","ssh")],
        [Button.inline(" VMESS MANAGER ","vmess"),
         Button.inline(" VLESS MANAGER ","vless")],
        [Button.inline(" TROJAN MANAGER ","trojan"),
         Button.inline(" SHDWSK MANAGER ","shadowsocks")],
        [Button.inline(" CHECK VPS INFO ","info"),
         Button.inline(" OTHER SETTING ","setting")],
        [Button.inline(" ‹ Back Menu › ","start")]
    ]

    sh = f' cat /etc/passwd | grep "home" | grep "false" | wc -l'
    ssh = subprocess.check_output(sh, shell=True).decode("ascii")
    vm = f' cat /etc/vmess/.vmess.db | grep "###" | wc -l'
    vms = subprocess.check_output(vm, shell=True).decode("ascii")
    vl = f' cat /etc/vless/.vless.db | grep "###" | wc -l'
    vls = subprocess.check_output(vl, shell=True).decode("ascii")
    tr = f' cat /etc/trojan/.trojan.db | grep "###" | wc -l'
    trj = subprocess.check_output(tr, shell=True).decode("ascii")
    sdss = f" cat /etc/os-release | grep -w PRETTY_NAME | head -n1 | sed 's/=//g' | sed 's/PRETTY_NAME//g'"
    namaos = subprocess.check_output(sdss, shell=True).decode("ascii")
    ipvps = f" curl -s ipv4.icanhazip.com"
    ipsaya = subprocess.check_output(ipvps, shell=True).decode("ascii")
    citsy = f" cat /etc/xray/city"
    city = subprocess.check_output(citsy, shell=True).decode("ascii")

    msg = f"""
━━━━━━━━━━━━━━━━━
**🇮🇩 ADMIN PANEL MENU 🇮🇩**
━━━━━━━━━━━━━━━━━
**» OS     :** `{namaos.strip().replace('"','')}`
**» CITY :** `{city.strip()}`
**» DOMAIN :** `{DOMAIN}`
**» IP VPS :** `{ipsaya.strip()}`
**» Total Account Created:** 

**» 🚀SSH OVPN    :** `{ssh.strip()}` __account__
**» 🎭XRAY VMESS  :** `{vms.strip()}` __account__
**» 🗼XRAY VLESS  :** `{vls.strip()}` __account__
**» 🎯XRAY TROJAN :** `{trj.strip()}` __account__
━━━━━━━━━━━━━━━━━━━━━━━ 
"""
    x = await event.edit(msg,buttons=inline)
    if not x:
        await event.reply(msg,buttons=inline)

@bot.on(events.CallbackQuery(data=b'topup'))
async def topup_request(event):
    await event.reply(f"Silakan hubungi admin {admin_username} untuk melakukan topup saldo. Sertakan username Anda saat menghubungi admin.")

@bot.on(events.CallbackQuery(data=b'reseller'))
async def reseller_request(event):
    await event.reply(f"Untuk menjadi reseller, silakan topup minimal 50.000 rupiah dengan menghubungi admin {admin_username}.")

@bot.on(events.NewMessage(pattern=r"/join"))
async def join_member(event):
    sender = await event.get_sender()
    if is_member(sender.id):
        await event.reply("Anda sudah menjadi member.")
        return
    
    add_member(sender.id)
    await event.reply(f"Selamat {sender.first_name}, Anda sekarang menjadi member! Anda dapat melakukan topup untuk menggunakan layanan bot.")

@bot.on(events.NewMessage(pattern=r"^/addsaldo (\d+) (\d+) (reseller|regular)$"))
async def add_saldo(event):
    if event.sender_id != admin_id:
        await event.reply("Anda tidak memiliki akses untuk menggunakan perintah ini.")
        return
    
    args = event.pattern_match.groups()
    user_id = int(args[0])
    amount = int(args[1])
    role = args[2]
    
    add_balance(user_id, amount, role)
    await event.reply(f"Saldo sebesar {amount} berhasil ditambahkan ke pengguna {user_id} sebagai {role}.")

# Placeholder functions for user data and balance management
def get_user_balance(user_id):
    return 20000

def add_balance(user_id, amount, role):
    pass

def deduct_balance(user_id, amount):
    pass

def create_user_account(user_id, service_type):
    pass

def get_user_role(user_id):
    return "regular"

def get_user_status(user_id):
    return "non-member"

def add_member(user_id):
    pass
