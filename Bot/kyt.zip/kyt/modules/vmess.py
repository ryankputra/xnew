from kyt import *

# CRATE VMESS
@bot.on(events.CallbackQuery(data=b'create-vmess'))
async def create_vmess(event):
    async def create_vmess_(event):
        async with bot.conversation(chat) as user:
            await event.respond('**Username:**')
            user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = (await user).raw_text

        async with bot.conversation(chat) as pw:
            await event.respond("**Quota:**")
            pw = pw.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            pw = (await pw).raw_text

        async with bot.conversation(chat) as pw1:
            await event.respond("**Limit-ip:**")
            pw1 = pw1.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            pw1 = (await pw1).raw_text

        async with bot.conversation(chat) as exp:
            await event.respond("**Expaired:**")
            exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            exp = (await exp).raw_text

        await event.edit("Processing.")
        for i in range(1, 5):
            await event.edit(f"Processing{'...' * i}")
            time.sleep(1)
        
        await event.edit("`Processing Crate Premium Account`")
        for percent in [0, 4, 8, 20, 36, 52, 84, 100]:
            await event.edit(f"`Processing... {percent}%\n{'█' * (percent // 4)}{'▒' * (25 - (percent // 4))}`")
            time.sleep(0.5)

        await event.edit("`Wait.. Setting up an Account`")
        cmd = f'printf "%s\n" "{user}" "{pw}" "{pw1}" "{exp}" | add-vme'
        city_cmd = "cat /etc/xray/city"
        city = subprocess.check_output(city_cmd, shell=True).decode("ascii")

        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except Exception as e:
            await event.respond(f"**User** `{user}` **Successfully Created**")
        else:
            today = DT.date.today()
            later = today + DT.timedelta(days=int(exp))
            b = [x.group() for x in re.finditer("vmess://(.*)", a)]
            z = base64.b64decode(b[0].replace("vmess://", "")).decode("ascii")
            z = json.loads(z)

            msg = f"""
**━━━━━━━━━━━━━━━━━**
**🐾🕊️ Xray/Vmess Account 🕊️🐾**
**━━━━━━━━━━━━━━━━━**
**» Remarks      :** `{z["ps"]}`
**» Domain       :** `{z["add"]}`
**» XRAY DNS     :** `{HOST}`
**» User Quota   :** `{pw} GB`
**» Port DNS     :** `443, 53`
**» port TLS     :** `222-1000`
**» Port NTLS    :** `80, 8080, 8081-9999`
**» Port GRPC    :** `443`
**» User ID      :** `{z["id"]}`
**» AlterId      :** `0`
**» Security     :** `auto`
**» NetWork      :** `(WS) or (gRPC)`
**» Path TLS     :** `(/multi path)/vmess`
**» Path NLS     :** `(/multi path)/vmess`
**» Path Dynamic :** `http://BUG.COM`
**» ServiceName  :** `vmess-grpc`
**━━━━━━━━━━━━━━━━━**
**» Link TLS     :** 
``{b[0].strip("'").replace(" ","")}``
**━━━━━━━━━━━━━━━━━**
**» Link NTLS    :** 
``{b[1].strip("'").replace(" ","")}``
**━━━━━━━━━━━━━━━━━**
**» Format OpenClash :** https://{DOMAIN}:81/vmess-{user}.txt
**━━━━━━━━━━━━━━━━━**
**» Expired Until:** `{later}`
**» 🤖@RyyVpn26**
``
◇━━━━━━━━━━━━━━━━━◇
*_PEMBELIAN BERHASIL_*
◇━━━━━━━━━━━━━━━━━◇
-» PRODUK : VMESS
-» REGION : {city.strip()}
-» REQ CONFIG : 
-» REQ NAMA : {user.strip()}
-» DEVICE : 1 IP
-» HARGA : 
-» AKTIF : {exp} HARI
-» TGL EXP : {later}
◇━━━━━━━━━━━━━━━━━◇
@RyyVpn26
``
"""
            await event.respond(msg)

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await create_vmess_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)

# TRIAL VMESS
@bot.on(events.CallbackQuery(data=b'trial-vmess'))
async def trial_vmess(event):
    async def trial_vmess_(event):
        async with bot.conversation(chat) as exp:
            await event.respond("**Minutes:**")
            exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            exp = (await exp).raw_text

        await event.edit("Processing.")
        for i in range(1, 5):
            await event.edit(f"Processing{'...' * i}")
            time.sleep(1)

        await event.edit("`Processing Crate Premium Account`")
        for percent in [0, 4, 8, 20, 36, 52, 84, 100]:
            await event.edit(f"`Processing... {percent}%\n{'█' * (percent // 4)}{'▒' * (25 - (percent // 4))}`")
            time.sleep(0.5)

        await event.edit("`Wait.. Setting up an Account`")
        cmd = f'printf "%s\n" "{exp}" | trial-vme'
        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except Exception as e:
            await event.respond(f"**User Trial Successfully Created**")
        else:
            today = DT.date.today()
            later = today + DT.timedelta(minutes=int(exp))
            b = [x.group() for x in re.finditer("vmess://(.*)", a)]
            z = base64.b64decode(b[0].replace("vmess://", "")).decode("ascii")
            z = json.loads(z)

            msg = f"""
**━━━━━━━━━━━━━━━━━**
**🐾🕊️ Xray/Vmess Account 🕊️🐾**
**━━━━━━━━━━━━━━━━━**
**» Remarks      :** `{z["ps"]}`
**» Domain       :** `{z["add"]}`
**» XRAY DNS     :** `{HOST}`
**» User Quota   :** `Unlimited`
**» Port DNS     :** `443, 53`
**» port TLS     :** `222-1000`
**» Port NTLS    :** `80, 8080, 8081-9999`
**» Port GRPC    :** `443`
**» User ID      :** `{z["id"]}`
**» AlterId      :** `0`
**» Security     :** `auto`
**» NetWork      :** `(WS) or (gRPC)`
**» Path TLS     :** `(/multi path)/vmess`
**» Path NLS     :** `(/multi path)/vmess`
**━━━━━━━━━━━━━━━━━**
**» Link TLS     :** 
`{b[0].strip("'").replace(" ","")}`
**━━━━━━━━━━━━━━━━━**
**» Link NTLS    :** 
`{b[1].strip("'").replace(" ","")}`
**━━━━━━━━━━━━━━━━━**
**» Format OpenClash :** https://{DOMAIN}:81/vmess-{z["ps"]}.txt
**━━━━━━━━━━━━━━━━━**
**» Expired Until:** `{later}`
**» 🤖@RyyVpn26**
"""
            await event.respond(msg)

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await trial_vmess_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)

# Kode selanjutnya tetap sama
