from kyt import *

# CREATE VMESS
@bot.on(events.CallbackQuery(data=b'create-vmess'))
async def create_vmess(event):
    async def create_vmess_(event):
        async with bot.conversation(chat) as user:
            await event.respond('**Username:**')
            user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = (await user).raw_text
        
        # Mengatur default values
        quota = 200  # dalam GB
        limit_ip = 2  # limit IP
        expired = 30  # dalam hari
        
        # Pengecekan saldo
        balance = check_balance(sender.id)  # Ganti dengan fungsi yang sesuai
        account_price = 10000  # Harga untuk akun VMess
        
        if balance < account_price:
            await event.respond("Saldo Anda tidak cukup untuk membuat akun.")
            return
        
        # Pemotongan saldo
        deduct_balance(sender.id, account_price)

        await event.edit("Processing.")
        await event.edit("Processing..")
        await event.edit("Processing...")
        await event.edit("Processing....")
        time.sleep(1)
        await event.edit("`Processing Create Premium Account`")
        time.sleep(1)
        await event.edit("`Processing... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(0)
        await event.edit("`Processing... 100%\n█████████████████████████ `")
        time.sleep(1)
        await event.edit("`Wait.. Setting up an Account`")
        cmd = f'printf "%s\n" "{user}" "{quota}" "{limit_ip}" "{expired}" | add-vme'
        city_cmd = f"cat /etc/xray/city"
        city = subprocess.check_output(city_cmd, shell=True).decode("ascii")
        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except:
            await event.respond(f"**User** `{user}` **Successfully Created**")
        else:
            today = DT.date.today()
            later = today + DT.timedelta(days=int(expired))
            b = [x.group() for x in re.finditer("vmess://(.*)", a)]
            z = base64.b64decode(b[0].replace("vmess://", "")).decode("ascii")
            z = json.loads(z)
            msg = f"""
**━━━━━━━━━━━━━━━━━**
**🐾🕊️ Xray/Vmess Account 🕊️🐾**
**━━━━━━━━━━━━━━━━━**
**» Remarks      :** `{z["ps"]}`
**» Domain       :** `{z["add"]}`
**» XRAY DNS     :** `{HOST}`
**» User Quota   :** `{quota} GB`
**» Port DNS     :** `443, 53`
**» Port TLS     :** `222-1000`
**» Port NTLS    :** `80, 8080, 8081-9999`
**» Port GRPC    :** `443`
**» User ID      :** `{z["id"]}`
**» AlterId      :** `0`
**» Security     :** `auto`
**» NetWork      :** `(WS) or (gRPC)`
**» Path TLS     :** `(/multi path)/vmess`
**» Path NLS     :** `(/multi path)/vmess`
**» ServiceName  :** `vmess-grpc`
**━━━━━━━━━━━━━━━━━**
**» Link TLS     :** 
``{b[0].strip("'").replace(" ","")}``
**━━━━━━━━━━━━━━━━━**
**» Expired Until:** `{later}`
**» 🤖@RyyVpn26**
``
◇━━━━━━━━━━━━━━━━━◇
*_PEMBELIAN BERHASIL_*
◇━━━━━━━━━━━━━━━━━◇
-» PRODUK : VMESS
-» REGION : {city.strip()}
-» REQ CONFIG : 
-» REQ NAMA : {user.strip()}
-» DEVICE : {limit_ip} IP
-» HARGA : 
-» AKTIF : {expired} HARI
-» TGL EXP : {later}
◇━━━━━━━━━━━━━━━━━◇
@RyyVpn26
``
"""
            await event.respond(msg)
    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await create_vmess_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)

# TRIAL VMESS
@bot.on(events.CallbackQuery(data=b'trial-vmess'))
async def trial_vmess(event):
    async def trial_vmess_(event):
        async with bot.conversation(chat) as exp:
            await event.respond("**Minutes:**")
            exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            exp = (await exp).raw_text
        
        # Mengatur default expired untuk trial
        expired = 0.5  # 30 menit dalam jam
        await event.edit("Processing.")
        await event.edit("Processing..")
        await event.edit("Processing...")
        time.sleep(1)
        await event.edit("`Processing Create Trial Account`")
        time.sleep(1)
        await event.edit("`Wait.. Setting up an Account`")
        cmd = f'printf "%s\n" "{expired}" | trial-vme'
        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except:
            await event.respond(f"**User Trial Successfully Created**")
        else:
            # Handle response as needed
            await event.respond(f"**User Trial Successfully Created**")
    
    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await trial_vmess_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)
