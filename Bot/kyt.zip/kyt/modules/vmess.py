from kyt import *

# Fungsi untuk memeriksa saldo
async def check_balance(user_id):
    # Logika untuk mendapatkan saldo pengguna
    pass  # Ganti dengan implementasi sebenarnya

# Fungsi untuk memeriksa jenis pengguna
def check_user_type(user_id):
    # Logika untuk memeriksa apakah pengguna adalah reseller atau member
    pass  # Ganti dengan implementasi sebenarnya

# Fungsi untuk mengurangi saldo
async def deduct_balance(user_id, amount):
    # Logika untuk mengurangi saldo pengguna
    pass  # Ganti dengan implementasi sebenarnya

# Fungsi untuk menghasilkan password
def generate_password():
    # Logika untuk menghasilkan password
    pass  # Ganti dengan implementasi sebenarnya

# CRATE VMESS
@bot.on(events.CallbackQuery(data=b'create-vmess'))
async def create_vmess(event):
    async def create_vmess_(event):
        chat = event.chat_id
        sender = await event.get_sender()

        # Cek saldo sebelum lanjut
        balance = await check_balance(sender.id)
        if balance <= 0:
            await event.answer("Saldo Anda habis. Silakan top up untuk melanjutkan.", alert=True)
            return

        # Cek apakah user adalah reseller atau member
        user_type = check_user_type(sender.id)  # Ganti dengan logika cek jenis user
        if user_type == "reseller":
            amount_to_deduct = 6000
        else:
            amount_to_deduct = 10000

        # Kurangi saldo
        await deduct_balance(sender.id, amount_to_deduct)

        # Mengatur nilai default
        quota = 200  # Default quota 200 GB
        limit_ip = 2  # Default limit IP 2
        expired = 30  # Default expired 30 hari

        # Minta username dari pengguna
        await event.respond("Silakan masukkan username untuk akun Anda:")
        username_event = await bot.wait_for(events.NewMessage(from_users=sender.id))

        username = username_event.message.message
        user = username.strip()  # Menghapus spasi di awal dan akhir
        pw = generate_password()  # Ganti dengan logika untuk menghasilkan password

        # Proses pembuatan akun
        await event.edit("Processing.")
        await event.edit("Processing..")
        await event.edit("Processing...")
        await event.edit("Processing....")
        time.sleep(1)
        await event.edit("`Processing Create Premium Account`")
        
        # Proses animasi progress
        for progress in [0, 4, 8, 20, 36, 52, 84, 100]:
            time.sleep(1)
            await event.edit(f"`Processing... {progress}%\n{'█' * (progress // 4)}{'▒' * (25 - (progress // 4))}`")

        await event.edit("`Wait.. Setting up an Account`")
        cmd = f'printf "%s\n" "{user}" "{pw}" "{limit_ip}" "{expired}" | add-vme'
        city_cmd = "cat /etc/xray/city"
        city = subprocess.check_output(city_cmd, shell=True).decode("ascii")
        
        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except Exception as e:
            await event.respond(f"**User** `{user}` **Successfully Created**")
        else:
            # Ambil data vmess
            b = [x.group() for x in re.finditer("vmess://(.*)", a)]
            z = base64.b64decode(b[0].replace("vmess://", "")).decode("ascii")
            z = json.loads(z)

            # Kirim pesan
            msg = f"""
**━━━━━━━━━━━━━━━━━**
**🐾🕊️ Xray/Vmess Account 🕊️🐾**
**━━━━━━━━━━━━━━━━━**
**» Remarks      :** `{z["ps"]}`
**» Domain       :** `{z["add"]}`
**» XRAY DNS     :** `{HOST}`
**» User Quota   :** `{quota} GB`
**» Port DNS     :** `443, 53`
**» User ID      :** `{z["id"]}`
**━━━━━━━━━━━━━━━━━**
"""
            await event.respond(msg)

    a = valid(str(sender.id))
    if a == "true":
        await create_vmess_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)

# TRIAL VMESS
@bot.on(events.CallbackQuery(data=b'trial-vmess'))
async def trial_vmess(event):
    async def trial_vmess_(event):
        async with bot.conversation(chat) as exp:
            await event.respond("**Minutes:**")
            exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            exp = (await exp).raw_text
        
        await event.edit("Processing.")
        await event.edit("Processing..")
        await event.edit("Processing...")
        await event.edit("Processing....")
        time.sleep(1)
        await event.edit("`Processing Create Premium Account`")
        
        # Proses animasi progress
        for progress in [0, 4, 8, 20, 36, 52, 84, 100]:
            time.sleep(1)
            await event.edit(f"`Processing... {progress}%\n{'█' * (progress // 4)}{'▒' * (25 - (progress // 4))}`")

        await event.edit("`Wait.. Setting up an Account`")
        cmd = f'printf "%s\n" "{exp}" | trial-vme'
        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except Exception as e:
            await event.respond(f"**User Trial Successfully Created**")
        else:
            # Ambil data vmess
            b = [x.group() for x in re.finditer("vmess://(.*)", a)]
            z = base64.b64decode(b[0].replace("vmess://", "")).decode("ascii")
            z = json.loads(z)
            msg = f"""
**━━━━━━━━━━━━━━━━━**
**🐾🕊️ Xray/Vmess Account 🕊️🐾**
**━━━━━━━━━━━━━━━━━**
**» Remarks      :** `{z["ps"]}`
**» Domain       :** `{z["add"]}`
**» XRAY DNS     :** `{HOST}`
**» User Quota   :** `{quota} GB`
**» Port DNS     :** `443, 53`
**» User ID      :** `{z["id"]}`
**━━━━━━━━━━━━━━━━━**
"""
            await event.respond(msg)

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await trial_vmess_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)
