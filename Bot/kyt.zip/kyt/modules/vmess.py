from kyt import *
import subprocess
import json
import base64
import re
import datetime as DT
import time
from telethon import events

# CREATE VMESS
@bot.on(events.CallbackQuery(data=b'create-vmess'))
async def create_vmess(event):
    async def create_vmess_(event):
        try:
            chat = event.chat_id
            sender = await event.get_sender()

            async with bot.conversation(chat) as user:
                await event.respond('**Buat Username:**')
                user = await user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                user = (await user).raw_text
            
            async with bot.conversation(chat) as pw:
                await event.respond("**Limit-Quota:**")
                pw = await pw.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                pw = (await pw).raw_text
            
            async with bot.conversation(chat) as pw1:
                await event.respond("**Limit-ip:**")
                pw1 = await pw1.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                pw1 = (await pw1).raw_text
            
            async with bot.conversation(chat) as exp:
                await event.respond("**Expaired:**")
                exp = await exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                exp = (await exp).raw_text
            
            await event.edit("Processing.")
            await event.edit("Processing..")
            await event.edit("Processing...")
            await event.edit("Processing....")
            time.sleep(1)
            await event.edit("`Processing Crate Premium Account`")
            
            progress_stages = [
                "0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒",
                "4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒",
                "8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒",
                "20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒",
                "36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒",
                "52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒",
                "84%\n█████████████████████▒▒▒▒",
                "100%\n█████████████████████████"
            ]
            
            for stage in progress_stages:
                await event.edit(f"`Processing... {stage}`")
                time.sleep(0.5)
            
            await event.edit("`Wait.. Setting up an Account`")
            cmd = f'printf "%s\n" "{user}" "{pw}" "{pw1}" "{exp}" | add-vme'
            city_cmd = f"cat /etc/xray/city"
            city = subprocess.check_output(city_cmd, shell=True).decode("ascii").strip()
            
            try:
                a = subprocess.check_output(cmd, shell=True).decode("utf-8")
            except subprocess.CalledProcessError as e:
                await event.respond("Error occurred while setting up account")
                return
            
            today = DT.date.today()
            later = today + DT.timedelta(days=int(exp))
            b = [x.group() for x in re.finditer("vmess://(.*)", a)]
            
            z = base64.b64decode(b[0].replace("vmess://", "")).decode("ascii")
            z = json.loads(z)
            z1 = base64.b64decode(b[1].replace("vmess://", "")).decode("ascii")
            z1 = json.loads(z1)
            
            msg = f"""
**━━━━━━━━━━━━━━━━━**
**🐾🕊️ Xray/Vmess Account 🕊️🐾**
**━━━━━━━━━━━━━━━━━**
**» Remarks      :** `{z["ps"]}`
**» Domain       :** `{z["add"]}`
**» XRAY DNS     :** `{HOST}`
**» User Quota   :** `{pw} GB`
**» Port DNS     :** `443, 53`
**» port TLS     :** `222-1000`
**» Port NTLS    :** `80, 8080, 8081-9999`
**» Port GRPC    :** `443`
**» User ID      :** `{z["id"]}`
**» AlterId      :** `0`
**» Security     :** `auto`
**» NetWork      :** `(WS) or (gRPC)`
**» Path TLS     :** `(/multi path)/vmess`
**» Path NLS     :** `(/multi path)/vmess`
**» Path Dynamic :** `http://BUG.COM`
**» ServiceName  :** `vmess-grpc`
**» Pub Key      :** `{PUB}`
**━━━━━━━━━━━━━━━━━**
**» Link TLS     :** 
``{b[0].strip("'").replace(" ", "")}``
**━━━━━━━━━━━━━━━━━**
**» Link NTLS    :** 
``{b[1].strip("'").replace(" ", "")}``
**━━━━━━━━━━━━━━━━━**
**» Format OpenClash :** https://{DOMAIN}:81/vmess-{user}.txt
**━━━━━━━━━━━━━━━━━**
**» Expired Until:** `{later}`
**» 🤖@RyyVpn26**

``
◇━━━━━━━━━━━━━━━━━◇
*_PEMBELIAN BERHASIL_*
◇━━━━━━━━━━━━━━━━━◇
-» PRODUK : VMESS
-» REGION : {city}
-» REQ CONFIG : 
-» REQ NAMA : {user}
-» DEVICE : 1 IP
-» HARGA : 
-» AKTIF : {exp} HARI
-» TGL EXP : {later}
◇━━━━━━━━━━━━━━━━━◇
@RyyVpn26
``
"""
            await event.respond(msg)
        except Exception as e:
            await event.respond(f"Terjadi kesalahan: {str(e)}")
            
    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await create_vmess_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)

# CHECK VMESS
@bot.on(events.CallbackQuery(data=b'cek-vmess'))
async def cek_vmess(event):
    async def cek_vmess_(event):
        cmd = 'bot-cek-vmess'
        try:
            z = subprocess.check_output(cmd, shell=True).decode("utf-8")
            await event.respond(f"{z}\n**Menampilkan Pengguna Vmess yang Terdaftar**\n**» 🤖@RyyVpn26**", buttons=[[Button.inline("‹ Menu Utama ›", "menu")]])
        except subprocess.CalledProcessError as e:
            await event.respond(f"Error: {e.output}")

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await cek_vmess_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)

# LOCK VMESS
@bot.on(events.CallbackQuery(data=b'lock-vmess'))
async def lock_vmess(event):
    async def lock_vmess_(event):
        chat = event.chat_id
        sender = await event.get_sender()

        async with bot.conversation(chat) as conv:
            await event.respond("**Username:**")
            username = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            username = (await username).raw_text

        cmd = f'printf "%s\n" "{username}" | lock-vm'
        try:
            subprocess.check_output(cmd, shell=True)
            await event.respond(f"**Pengguna** `{username}` **Berhasil Dikunci**")
        except subprocess.CalledProcessError:
            await event.respond(f"**Gagal mengunci pengguna** `{username}`")

    a = valid(str(sender.id))
    if a == "true":
        await lock_vmess_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)

# UNLOCK VMESS
@bot.on(events.CallbackQuery(data=b'unlock-vmess'))
async def unlock_vmess(event):
    async def unlock_vmess_(event):
        chat = event.chat_id
        sender = await event.get_sender()

        async with bot.conversation(chat) as conv:
            await event.respond("**Username:**")
            username = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            username = (await username).raw_text

        cmd = f'printf "%s\n" "{username}" | unlock-vm'
        try:
            subprocess.check_output(cmd, shell=True)
            await event.respond(f"**Pengguna** `{username}` **Berhasil Dibuka Kuncinya**")
        except subprocess.CalledProcessError:
            await event.respond(f"**Gagal membuka kunci pengguna** `{username}`")

    a = valid(str(sender.id))
    if a == "true":
        await unlock_vmess_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)

# DELETE VMESS
@bot.on(events.CallbackQuery(data=b'delete-vmess'))
async def delete_vmess(event):
    async def delete_vmess_(event):
        chat = event.chat_id
        sender = await event.get_sender()

        async with bot.conversation(chat) as conv:
            await event.respond("**Username:**")
            username = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            username = (await username).raw_text

        cmd = f'printf "%s\n" "{username}" | del-vm'
        try:
            subprocess.check_output(cmd, shell=True)
            await event.respond(f"**Pengguna** `{username}` **Berhasil Dihapus**")
        except subprocess.CalledProcessError:
            await event.respond(f"**Gagal menghapus pengguna** `{username}`")

    a = valid(str(sender.id))
    if a == "true":
        await delete_vmess_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)

# TRIAL VMESS
@bot.on(events.CallbackQuery(data=b'trial-vmess'))
async def trial_vmess(event):
    async def trial_vmess_(event):
        try:
            chat = event.chat_id
            sender = await event.get_sender()

            async with bot.conversation(chat) as user:
                await event.respond('**Buat Username:**')
                user = await user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                user = (await user).raw_text
            
            async with bot.conversation(chat) as exp:
                await event.respond("**Limit Waktu (Menit):**")
                exp = await exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                exp = (await exp).raw_text
            
            await event.edit("Processing.")
            time.sleep(1)
            await event.edit("`Processing Trial Account`")
            
            cmd = f'printf "%s\n" "{user}" "{exp}" | add-trial-vme'
            try:
                a = subprocess.check_output(cmd, shell=True).decode("utf-8")
            except subprocess.CalledProcessError:
                await event.respond("**Gagal membuat akun trial**")
                return
            
            msg = f"""
**━━━━━━━━━━━━━━━━━**
**🐾🕊️ Xray/Vmess Trial Account 🕊️🐾**
**━━━━━━━━━━━━━━━━━**
**» Username    :** `{user}`
**» Expired Until:** `{exp} Menit`
**» 🤖@RyyVpn26**
"""
            await event.respond(msg)

        except subprocess.CalledProcessError:
            await event.respond(f"**Gagal membuat akun trial**")

    a = valid(str(sender.id))
    if a == "true":
        await trial_vmess_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)
