from kyt import *

# CREATE VMESS
@bot.on(events.CallbackQuery(data=b'create-vmess'))
async def create_vmess(event):
    async def create_vmess_(event):
        async with bot.conversation(chat) as user:
            await event.respond('**Buat Username:**')
            user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = (await user).raw_text
        async with bot.conversation(chat) as pw:
            await event.respond("**Limit-Quota:**")
            pw = pw.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            pw = (await pw).raw_text
        async with bot.conversation(chat) as pw1:
            await event.respond("**Limit-ip:**")
            pw1 = pw1.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            pw1 = (await pw1).raw_text
        async with bot.conversation(chat) as exp:
            await event.respond("**Expired:**")
            exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            exp = (await exp).raw_text
        await event.edit("Processing...")
        time.sleep(1)
        cmd = f'printf "%s\n" "{user}" "{pw}" "{pw1}" "{exp}" | add-vme'
        city_cmd = f"cat /etc/xray/city"
        city = subprocess.check_output(city_cmd, shell=True).decode("ascii")
        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
            await event.respond(f"**User** `{user}` **Successfully Created**")
        except Exception as e:
            await event.respond(f"Error: {str(e)}")
            return
        
        today = DT.date.today()
        later = today + DT.timedelta(days=int(exp))
        b = [x.group() for x in re.finditer("vmess://(.*)", a)]
        z = base64.b64decode(b[0].replace("vmess://", "")).decode("ascii")
        z = json.loads(z)
        msg = f"""
**━━━━━━━━━━━━━━━━━**
**🐾🕊️ Akun Xray/Vmess 🕊️🐾**
**━━━━━━━━━━━━━━━━━**
**» Remarks      :** `{z["ps"]}`
**» Domain       :** `{z["add"]}`
**» User Quota   :** `{pw} GB`
**» Expired Until:** `{later}`
**» Link TLS     :** 
``{b[0].strip("'").replace(" ","")}``
**» Link NTLS    :** 
``{b[1].strip("'").replace(" ","")}``
**━━━━━━━━━━━━━━━━━**
"""
        await event.respond(msg)

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await create_vmess_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)

# TRIAL VMESS
@bot.on(events.CallbackQuery(data=b'trial-vmess'))
async def trial_vmess(event):
    async def trial_vmess_(event):
        async with bot.conversation(chat) as exp:
            await event.respond("**Minutes:**")
            exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            exp = (await exp).raw_text
        await event.edit("Processing...")
        time.sleep(1)
        cmd = f'printf "%s\n" "{exp}" | trial-vme'
        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
            await event.respond(f"**User Trial Successfully Created**")
        except Exception as e:
            await event.respond(f"Error: {str(e)}")
            return
        
        b = [x.group() for x in re.finditer("vmess://(.*)", a)]
        z = base64.b64decode(b[0].replace("vmess://", "")).decode("ascii")
        z = json.loads(z)
        msg = f"""
**━━━━━━━━━━━━━━━━━**
**🐾🕊️ Akun Xray/Vmess Trial 🕊️🐾**
**━━━━━━━━━━━━━━━━━**
**» Remarks      :** `{z["ps"]}`
**» Domain       :** `{z["add"]}`
**» Expired Until:** `{later}`
**» Link TLS     :** 
``{b[0].strip("'").replace(" ","")}``
**━━━━━━━━━━━━━━━━━**
"""
        await event.respond(msg)

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await trial_vmess_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)

# LOCK VMESS
@bot.on(events.CallbackQuery(data=b'lock-vmess'))
async def lock_vmess(event):
    async def lock_vmess_(event):
        async with bot.conversation(chat) as exp:
            await event.respond("**Username:**")
            exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            exp = (await exp).raw_text
        await event.edit("Processing...")
        cmd = f'printf "%s\n" "{exp}" | lock-vm'
        try:
            subprocess.check_output(cmd, shell=True)
            await event.respond(f"**User** `{exp}` **Successfully Locked**")
        except Exception as e:
            await event.respond(f"Error: {str(e)}")
            return

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await lock_vmess_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)

# UNLOCK VMESS
@bot.on(events.CallbackQuery(data=b'unlock-vmess'))
async def unlock_vmess(event):
    async def unlock_vmess_(event):
        async with bot.conversation(chat) as exp:
            await event.respond("**Username:**")
            exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            exp = (await exp).raw_text
        await event.edit("Processing...")
        cmd = f'printf "%s\n" "{exp}" | unlock-vm'
        try:
            subprocess.check_output(cmd, shell=True)
            await event.respond(f"**User** `{exp}` **Successfully Unlocked**")
        except Exception as e:
            await event.respond(f"Error: {str(e)}")
            return

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await unlock_vmess_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)

# CEK VMESS
@bot.on(events.CallbackQuery(data=b'cek-vmess'))
async def cek_vmess(event):
    async def cek_vmess_(event):
        cmd = 'bot-cek-ws'
        x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
        await event.respond(f"**Daftar Pengguna VMess yang Masuk**\n{z}")

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await cek_vmess_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)

# DELETE VMESS
@bot.on(events.CallbackQuery(data=b'delete-vmess'))
async def delete_vmess(event):
    async def delete_vmess_(event):
        async with bot.conversation(chat) as user:
            await event.respond('**Username:**')
            user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = (await user).raw_text
        cmd = f'printf "%s\n" "{user}" | del-vme'
        try:
            subprocess.check_output(cmd, shell=True)
            await event.respond(f"**User** `{user}` **Successfully Deleted**")
        except Exception as e:
            await event.respond(f"Error: {str(e)}")
            return

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await delete_vmess_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)

# MENU VMESS
@bot.on(events.CallbackQuery(data=b'vmess'))
async def vmess(event):
    async def vmess_(event):
        inline = [
            [Button.inline(" TRIAL VMESS ", "trial-vmess"),
            Button.inline(" CREATE VMESS ", "create-vmess")],
            [Button.inline(" CHECK VMESS ", "cek-vmess"),
            Button.inline(" DELETE VMESS ", "delete-vmess")],
            [Button.inline(" LOCK VMESS ", "lock-vmess"),
            Button.inline(" UNLOCK VMESS ", "unlock-vmess")],
            [Button.inline("‹ Main Menu ›", "menu")]
        ]
        z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
        msg = f"""
━━━━━━━━━━━━━━━━
**🇮🇩 MANAGER VMESS 🇮🇩**
━━━━━━━━━━━━━━━━
🔰 **» Service:** `VMess`
🔰 **» Host:** `{HOST}`
🔰 **» Location:** `{z['country']}, {z['region']}, {z['city']}`
🔰 **» TimeZone:** `{z['timezone']}`
🔰 **» ISP:** `{z['isp']}`
━━━━━━━━━━━━━━━━
"""
        await event.edit(msg, buttons=inline)

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await vmess_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)
