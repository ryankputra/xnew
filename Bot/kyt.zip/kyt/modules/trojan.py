from kyt import *
import subprocess
import re
import time
import datetime as DT
import shlex
import json

# =================== HELPER FUNCTIONS ===================
async def show_progress(event):
    """Menampilkan animasi progress bar"""
    steps = [
        ("Proses.", 0.5),
        ("Proses..", 0.5),
        ("Proses...", 0.5),
        ("Proses....", 0.5),
        ("`Memulai pembuatan akun`", 1),
        ("`Proses... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `", 1),
        ("`Proses... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `", 0.3),
        ("`Proses... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `", 0.3),
        ("`Proses... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `", 0.3),
        ("`Proses... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `", 0.5),
        ("`Proses... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `", 0.5),
        ("`Proses... 84%\n█████████████████████▒▒▒▒ `", 0.3),
        ("`Proses... 100%\n█████████████████████████ `", 1),
        ("`Menyiapkan hasil...`", 1)
    ]
    
    for msg, delay in steps:
        await event.edit(msg)
        time.sleep(delay)

async def get_user_input(event, prompt):
    """Mendapatkan input dari pengguna dengan sanitasi"""
    async with bot.conversation(event.chat_id) as conv:
        await event.respond(prompt)
        response = await conv.wait_event(events.NewMessage(incoming=True))
        return shlex.quote(response.raw_text.strip())

async def execute_shell(cmd):
    """Eksekusi command shell dengan error handling"""
    try:
        result = subprocess.run(
            cmd,
            shell=True,
            check=True,
            capture_output=True,
            text=True,
            timeout=30
        )
        return result.stdout.strip()
    except subprocess.CalledProcessError as e:
        error_msg = f"""
        🚨 **Gagal Mengeksekusi Perintah** 🚨
        ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
        ▸ **Kode Error:** `{e.returncode}`
        ▸ **Pesan Error:**
        ```{e.stderr.strip() or 'Tidak ada pesan error'}```
        ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
        """
        raise Exception(error_msg)
    except subprocess.TimeoutExpired:
        raise Exception("⏳ **Timeout**: Proses terlalu lama, silakan coba lagi")

def parse_trojan_links(output):
    """Parsing output untuk mendapatkan link Trojan"""
    try:
        links = re.findall(r"trojan://(.*?)\n", output)
        if len(links) < 2:
            raise ValueError("Format output tidak valid")
        
        return {
            "ws": links[0].strip(),
            "grpc": links[1].strip(),
            "uuid": re.search(r"trojan://(.*?)@", links[0]).group(1),
            "domain": re.search(r"@(.*?):", links[0]).group(1)
        }
    except Exception as e:
        raise ValueError(f"Gagal parsing output: {str(e)}")

# =================== MAIN HANDLERS ===================
@bot.on(events.CallbackQuery(data=b'create-trojan'))
async def create_trojan(event):
    async def process_create():
        try:
            # Ambil input user
            inputs = [
                ("**Buat Username:**", "user"),
                ("**Limit Quota (GB):**", "quota"),
                ("**Limit IP:**", "ip_limit"),
                ("**Masa Aktif (hari):**", "expiry")
            ]
            
            params = {}
            for prompt, key in inputs:
                params[key] = await get_user_input(event, prompt)
                if not params[key].isdigit() and key != "user":
                    raise ValueError(f"Input {key} harus angka!")

            # Tampilkan progress
            await show_progress(event)

            # Eksekusi command
            cmd = f'printf "%s\\n" {params["user"]} {params["quota"]} {params["ip_limit"]} {params["expiry"]} | add-tro'
            output = await execute_shell(cmd)
            
            # Parse output
            details = parse_trojan_links(output)
            expiry_date = DT.date.today() + DT.timedelta(days=int(params["expiry"]))

            # Format pesan
            msg = f"""
            🛡️ **TROJAN ACCOUNT CREATED** 🛡️
            ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
            ▸ **Remarks:** `{params['user']}`
            ▸ **Domain:** `{details['domain']}`
            ▸ **Quota:** `{params['quota']} GB`
            ▸ **IP Limit:** `{params['ip_limit']}`
            ▸ **Expired:** `{expiry_date.strftime('%d %b %Y')}`
            ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
            🔗 **WS Link:**
            `{details['ws']}`
            ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
            🔗 **gRPC Link:**
            `{details['grpc']}`
            ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
            📁 **OpenClash Config:**
            `https://{details['domain']}:81/trojan-{params['user']}.txt`
            ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
            ⚠️ **Aktifkan sebelum {expiry_date.strftime('%d %b %Y')}**
            """
            await event.respond(msg)

        except ValueError as e:
            await event.respond(f"❌ **Input Error:**\n{str(e)}")
        except Exception as e:
            await event.respond(f"🚨 **Creation Failed:**\n{str(e)}")

    if valid(str((await event.get_sender()).id)):
        await process_create()
    else:
        await event.answer("🔒 Akses Ditolak", alert=True)

@bot.on(events.CallbackQuery(data=b'delete-trojan'))
async def delete_trojan(event):
    async def process_delete():
        try:
            username = await get_user_input(event, "**Username untuk dihapus:**")
            await show_progress(event)
            
            cmd = f'printf "%s\\n" {username} | del-tro'
            await execute_shell(cmd)
            
            await event.respond(f"✅ **Success Deleted:**\n`{username}`")

        except Exception as e:
            await event.respond(f"❌ **Deletion Failed:**\n{str(e)}")

    if valid(str((await event.get_sender()).id)):
        await process_delete()
    else:
        await event.answer("🔒 Akses Ditolak", alert=True)

@bot.on(events.CallbackQuery(data=b'trial-trojan'))
async def trial_trojan(event):
    async def process_trial():
        try:
            minutes = await get_user_input(event, "**Durasi Trial (menit):**")
            if not minutes.isdigit():
                raise ValueError("Input harus angka!")
            
            await show_progress(event)
            
            cmd = f'printf "%s\\n" {minutes} | trial-tro'
            output = await execute_shell(cmd)
            
            details = parse_trojan_links(output)
            
            msg = f"""
            🧪 **TRIAL TROJAN ACCOUNT** 🧪
            ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
            ▸ **Domain:** `{details['domain']}`
            ▸ **Durasi:** `{minutes} menit`
            ▸ **UUID:** `{details['uuid']}`
            ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
            🔗 **WS Link:**
            `{details['ws']}`
            ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
            🔗 **gRPC Link:**
            `{details['grpc']}`
            ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
            ⚠️ **Masa trial akan berakhir dalam {minutes} menit**
            """
            await event.respond(msg)

        except Exception as e:
            await event.respond(f"❌ **Trial Failed:**\n{str(e)}")

    if valid(str((await event.get_sender()).id)):
        await process_trial()
    else:
        await event.answer("🔒 Akses Ditolak", alert=True)

@bot.on(events.CallbackQuery(data=b'cek-trojan'))
async def cek_trojan(event):
    async def process_check():
        try:
            cmd = 'bot-cek-tr'
            output = await execute_shell(cmd)
            
            msg = f"""
            📊 **ACTIVE TROJAN USERS** 📊
            ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
            ```{output}```
            ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
            ⚠️ **Update terakhir:** {DT.datetime.now().strftime('%d/%m/%Y %H:%M')}
            """
            await event.respond(msg)

        except Exception as e:
            await event.respond(f"❌ **Check Failed:**\n{str(e)}")

    if valid(str((await event.get_sender()).id)):
        await process_check()
    else:
        await event.answer("🔒 Akses Ditolak", alert=True)

@bot.on(events.CallbackQuery(data=b'trojan'))
async def trojan_menu(event):
    menu = [
        [Button.inline("➕ BUAT TROJAN", "create-trojan"),
         Button.inline("🆓 TRIAL", "trial-trojan")],
        [Button.inline("📋 LIST AKUN", "cek-trojan"),
         Button.inline("🗑️ HAPUS AKUN", "delete-trojan")],
        [Button.inline("🔙 MENU UTAMA", "menu")]
    ]
    
    info = requests.get("http://ip-api.com/json").json()
    msg = f"""
    🛠️ **TROJAN MANAGER** 🛠️
    ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
    ▸ **Server:** `{DOMAIN}`
    ▸ **ISP:** `{info.get('isp', 'Unknown')}`
    ▸ **Lokasi:** `{info.get('country', 'Unknown')}`
    ▸ **Protocol:** `TCP/WS + gRPC`
    ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
    ⚠️ **Fitur yang tersedia:**
    - Auto Notifikasi Telegram
    - Multi Protocol (WS/gRPC)
    - Sistem Quota & Limit IP
    - Manajemen Akun Lengkap
    """
    await event.edit(msg, buttons=menu)

# =================== RUN BOT ===================
if __name__ == '__main__':
    bot.run_until_disconnected()