from kyt import *

# Buat Trojan
@bot.on(events.CallbackQuery(data=b'create-trojan'))
async def create_trojan(event):
    async def create_trojan_(event):
        async with bot.conversation(chat) as user:
            await event.respond('**Buat Username:**')
            user_msg = await user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = user_msg.raw_text
        async with bot.conversation(chat) as pw:
            await event.respond("**Limit Quota (GB):**")
            pw_msg = await pw.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            pw = pw_msg.raw_text
        async with bot.conversation(chat) as pw1:
            await event.respond("**Limit IP:**")
            pw1_msg = await pw1.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            pw1 = pw1_msg.raw_text
        async with bot.conversation(chat) as exp:
            await event.respond("**Masa Aktif (hari):**")
            exp_msg = await exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            exp = exp_msg.raw_text

        # Tampilan progress
        await event.edit("Proses.")
        await event.edit("Proses..")
        await event.edit("Proses...")
        await event.edit("Proses....")
        time.sleep(1)
        await event.edit("`Proses buat Akun Trojan`")
        time.sleep(1)
        await event.edit("`Proses... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(0)
        await event.edit("`Proses... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(0)
        await event.edit("`Proses... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(0)
        await event.edit("`Proses... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Proses... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Proses... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(0)
        await event.edit("`Proses... 84%\n█████████████████████▒▒▒▒ `")
        time.sleep(0)
        await event.edit("`Proses... 100%\n█████████████████████████ `")
        time.sleep(1)
        await event.edit("`Tunggu.. Sedang upload Akun`")

        # Jalankan command untuk membuat akun Trojan
        cmd = f'printf "%s\n" "{user}" "{pw}" "{pw1}" "{exp}" | add-tro'
        try:
            output = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except Exception as e:
            await event.respond(f"**Gagal membuat akun Trojan:** {e}")
            return

        # Parsing output untuk mendapatkan link Trojan
        links = [x.group() for x in re.finditer("trojan://(.*)", output)]
        if len(links) < 2:
            await event.respond("Gagal membuat akun Trojan, output tidak lengkap.")
            return

        # Ekstrak detail dari link Trojan
        try:
            domain = re.search("@(.*?):", links[0]).group(1)
            uuid = re.search("trojan://(.*?)@", links[0]).group(1)
        except Exception as e:
            await event.respond(f"Error parsing detail Trojan: {e}")
            return

        # Hitung tanggal expired
        today = DT.date.today()
        later = today + DT.timedelta(days=int(exp))

        # Buat pesan untuk dikirim ke pengguna
        msg = f"""
**━━━━━━━━━━━━━━━━━**
**🐾🕊️ Xray/Trojan Account 🕊️🐾**
**━━━━━━━━━━━━━━━━━**
**» Remarks       :** `{user}`
**» Host Server   :** `{domain}`
**» User Quota    :** `{pw} GB`
**» Limit IP      :** `{pw1}`
**» Port TLS      :** `443`
**» UUID          :** `{uuid}`
**━━━━━━━━━━━━━━━━━**
**» Link WS       :** 
`{links[0].strip().replace(" ", "")}`
**━━━━━━━━━━━━━━━━━**
**» Link GRPC     :** 
`{links[1].strip().replace(" ", "")}`
**━━━━━━━━━━━━━━━━━**
**» Expired Until :** `{later}`
**» 🤖@RyyVpn26**
"""
        await event.respond(msg)

    chat = event.chat_id
    sender = await event.get_sender()
    if valid(str(sender.id)) == "true":
        await create_trojan_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)


# Trial Trojan
@bot.on(events.CallbackQuery(data=b'trial-trojan'))
async def trial_trojan(event):
    async def trial_trojan_(event):
        async with bot.conversation(chat) as exp:
            await event.respond("**Durasi Trial (menit):**")
            exp_msg = await exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            exp = exp_msg.raw_text

        # Tampilan progress
        await show_progress(event)

        # Jalankan command untuk membuat akun trial Trojan
        cmd = f'printf "%s\n" "{exp}" | trial-tro'
        try:
            output = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except Exception as e:
            await event.respond(f"**Gagal membuat akun trial Trojan:** {e}")
            return

        # Parsing output untuk mendapatkan link Trojan
        links = [x.group() for x in re.finditer("trojan://(.*)", output)]
        if len(links) < 2:
            await event.respond("Gagal membuat akun trial Trojan, output tidak lengkap.")
            return

        # Buat pesan untuk dikirim ke pengguna
        msg = f"""
**━━━━━━━━━━━━━━━━━**
**🐾🕊️ Xray/Trojan Trial Account 🕊️🐾**
**━━━━━━━━━━━━━━━━━**
**» Remarks       :** `Trial Account`
**» Host Server   :** `{DOMAIN}`
**» User Quota    :** `Unlimited`
**» Port TLS      :** `443`
**» UUID          :** `{re.search("trojan://(.*?)@", links[0]).group(1)}`
**━━━━━━━━━━━━━━━━━**
**» Link WS       :** 
`{links[0].strip().replace(" ", "")}`
**━━━━━━━━━━━━━━━━━**
**» Link GRPC     :** 
`{links[1].strip().replace(" ", "")}`
**━━━━━━━━━━━━━━━━━**
**» Expired Until :** `{exp} Menit`
**» 🤖@RyyVpn26**
"""
        await event.respond(msg)

    chat = event.chat_id
    sender = await event.get_sender()
    if valid(str(sender.id)) == "true":
        await trial_trojan_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)


# Menu Trojan
@bot.on(events.CallbackQuery(data=b'trojan'))
async def trojan_menu(event):
    inline = [
        [Button.inline("TRIAL TROJAN", "trial-trojan"),
         Button.inline("BUAT TROJAN", "create-trojan")],
        [Button.inline("CEK TROJAN", "cek-trojan"),
         Button.inline("HAPUS TROJAN", "delete-trojan")],
        [Button.inline("‹ MENU UTAMA ›", "menu")]
    ]
    
    info = requests.get("http://ip-api.com/json").json()
    msg = f"""
**━━━━━━━━━━━━━━━━━━━**
**🔧 TROJAN MANAGER 🔧**
**━━━━━━━━━━━━━━━━━━━**
**» Server:** `{DOMAIN}`
**» ISP:** `{info.get('isp', 'Unknown')}`
**» Lokasi:** `{info.get('country', 'Unknown')}`
**» Protocol:** `TCP/WS + gRPC`
**━━━━━━━━━━━━━━━━━━━**
**» 🤖@RyyVpn26**
"""
    await event.edit(msg, buttons=inline)
    sender = await event.get_sender()
    if valid(str(sender.id)) == "true":
        await trojan_(event)
    else:
        await event.answer("Access Denied", alert=True)
