from kyt import *
import subprocess

@bot.on(events.NewMessage(pattern=r"(?:.start|/start)$"))
@bot.on(events.CallbackQuery(data=b'start'))
async def start(event):
    inline = [
        [Button.inline("PANEL CREATE ACCOUNT", "menu")],
        [Button.url("PRIVATE MESSAGE", "https://t.me/RyyVpn26"),
         Button.url("ORDER SCRIPT", "https://wa.me/6287767287284")]
    ]
    
    sender = await event.get_sender()
    if is_member(sender.id):  # Cek apakah user sudah menjadi member
        # Ambil informasi dari sistem
        namaos = get_os_name()
        city = get_city()
        ipsaya = get_ip()
        
        msg = f"""
━━━━━━━━━━━━━━━━━━━
**🇮🇩 Ryy.V2 PANEL MENU 🇮🇩**
━━━━━━━━━━━━━━━━━━━
🔰 **» OS     :** `{namaos}`
🔰 **» CITY :** `{city}`
🔰 **» DOMAIN :** `{DOMAIN}`
🔰 **» IP VPS :** `{ipsaya}`
━━━━━━━━━━━━━━━━━━━━━━━
"""
        await event.reply(msg, buttons=inline)  # Kirim pesan dengan tombol
    else:
        await event.reply("Akses Ditolak. Anda harus menjadi member untuk mengakses menu ini.")

def get_os_name():
    sh = "cat /etc/os-release | grep -w PRETTY_NAME | head -n1 | sed 's/=//g' | sed 's/PRETTY_NAME//g'"
    return subprocess.check_output(sh, shell=True).decode("ascii").strip().replace('"', '')

def get_ip():
    ipvps = "curl -s ipv4.icanhazip.com"
    return subprocess.check_output(ipvps, shell=True).decode("ascii").strip()

def get_city():
    cit = "cat /etc/xray/city"
    return subprocess.check_output(cit, shell=True).decode("ascii").strip()
